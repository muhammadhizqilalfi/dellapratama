__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/078aa80d47ca3298.js",
  "static/chunks/turbopack-31d38390dd4474f9.js"
])
