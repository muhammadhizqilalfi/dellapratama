__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/078aa80d47ca3298.js",
  "static/chunks/turbopack-a519044789c06a28.js"
])
