globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/078aa80d47ca3298.js",
      "static/chunks/turbopack-31d38390dd4474f9.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/078aa80d47ca3298.js",
      "static/chunks/turbopack-a519044789c06a28.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/5564f493499345f1.js",
    "static/chunks/202abb9aed9e828b.js",
    "static/chunks/08b60b045956f1b1.js",
    "static/chunks/turbopack-85c9eae90b28ce14.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];